#include "Beaujean-Belabbas-Lagrou-Lorentz-Sommet.h"


Sommet::Sommet()
{
    mDatePlusTard = 0;
    mDatePlusTot = 0;
}
