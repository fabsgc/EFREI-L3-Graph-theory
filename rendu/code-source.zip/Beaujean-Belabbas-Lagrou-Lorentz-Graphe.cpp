#include "Beaujean-Belabbas-Lagrou-Lorentz-Graphe.h"

Graphe::Graphe()
{
    mNSommets = 0;
    mArcs = 0;
    mDateFinProjet = 0;
    mCircuits = false;
}
